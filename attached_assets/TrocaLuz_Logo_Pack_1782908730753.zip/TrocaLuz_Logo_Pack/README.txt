TROCALUZ — LOGO & BRAND ASSET PACK
===================================
For use across the TrocaLuz website. Use ONLY these files.
Do NOT recreate, redraw, or regenerate the logo — use the assets provided here.

-----------------------------------
BRAND COLOURS (use these exact hex)
-----------------------------------
Green (primary / action)   #0E9F6E   -> buttons, primary CTAs, "TROCA", bolt back
Green hover                #0B8A5F   -> button hover
Green text (on light)      #047857   -> green links/text on white (passes contrast)
Yellow (signal / accent)   #FFD64D   -> "LUZ", bolt front, stat numbers, highlights
Navy (dark surface)        #0E1525   -> dark sections, footer, hero, app-icon tiles
Lime (accent only)         #5EE0A0   -> focus glow / tiny highlights only

Rule: green is the only button/action colour. Yellow is a signal colour only
(never a button or CTA link).

-----------------------------------
WHAT'S IN THE PACK
-----------------------------------
01_primary_lockup/   Bolt + "TROCALUZ" wordmark. The main logo.
    trocaluz-lockup-color.png (+@2x, +@3x)  -> on light/white backgrounds
    trocaluz-lockup-white.png (+@2x)        -> on navy / dark / photo backgrounds

02_wordmark/         "TROCALUZ" text only, no bolt (use where the bolt is separate).
    trocaluz-wordmark-color.png (+@2x, +@3x)
    trocaluz-wordmark-white.png (+@2x)

03_icon_bolt/        The bolt mark on its own.
    trocaluz-bolt.svg        -> VECTOR, scales to any size, use this by default
    trocaluz-bolt-white.svg  -> mono white, for dark backgrounds
    trocaluz-bolt-navy.svg   -> mono navy, for light backgrounds
    trocaluz-bolt-512.png / -256.png / -white-512.png -> raster fallbacks

04_favicon_app_icons/
    favicon.ico               -> browser tab (16/32/48 bundled)
    favicon-16/32/48.png      -> individual sizes
    apple-touch-icon.png      -> 180x180, bolt on navy tile (iOS)
    apple-touch-icon-white.png-> 180x180, bolt on white tile (alt)
    icon-192.png / icon-512.png -> PWA / Android

05_social_og/
    trocaluz-og-1200x630.png  -> default Open Graph / social share image
                                 (WhatsApp, LinkedIn, X link previews)

-----------------------------------
WHERE TO USE WHAT
-----------------------------------
Header / nav (light bg)     -> 01 lockup-color  (display ~140-180px wide; @2x for retina)
Header / nav (navy bg)      -> 01 lockup-white
Footer (navy)               -> 01 lockup-white
Browser tab                 -> 04 favicon.ico + favicon PNGs
iOS home screen             -> 04 apple-touch-icon.png
Android / PWA               -> 04 icon-192 / icon-512
Default social preview      -> 05 og image (per-page OG is set via meta tags later)
Anywhere the mark alone      -> 03 trocaluz-bolt.svg (vector, preferred)

-----------------------------------
FAVICON / META — READY TO PASTE (into <head>)
-----------------------------------
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<meta property="og:image" content="https://trocaluz.com/trocaluz-og-1200x630.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
(PWA: reference icon-192.png and icon-512.png in site.webmanifest)

-----------------------------------
RULES (clear space, min size, do/don't)
-----------------------------------
- Clear space: keep empty padding around the lockup equal to the height of the bolt.
- Minimum size: lockup no smaller than ~120px wide; bolt icon no smaller than 16px.
- On dark/navy/photo backgrounds ALWAYS use the -white version (never the green
  wordmark on navy at small sizes).
- Do NOT recolour, stretch, rotate, add shadows/gradients, or place the colour
  lockup on a busy background.
- Do NOT recreate the logo from scratch — use these files.

-----------------------------------
NOTE ON FORMAT / RESOLUTION
-----------------------------------
- The BOLT is vector (SVG) — infinitely scalable, crisp at any size. Prefer it.
- The LOCKUP and WORDMARK are raster PNG (exported at 400x80 native), provided at
  @1x/@2x/@3x. These are sufficient for standard web/header use. For large-format
  or print use later, export an SVG lockup from Canva (Canva Pro exports SVG) and
  drop it into 01_/02_ as trocaluz-lockup.svg.
